// src/data/ClientList.js

export const clientLogos = [
  new URL("@/assets/images/clients-and-partners/boa.png", import.meta.url).href,
  new URL("@/assets/images/clients-and-partners/grm.png", import.meta.url).href,
  new URL("@/assets/images/clients-and-partners/chubb.png", import.meta.url)
    .href,
  new URL("@/assets/images/clients-and-partners/fpg.png", import.meta.url).href,
  new URL("@/assets/images/clients-and-partners/heksa.png", import.meta.url)
    .href,
  new URL("@/assets/images/clients-and-partners/equity.png", import.meta.url)
    .href,
  new URL("@/assets/images/clients-and-partners/indore.png", import.meta.url)
    .href,
  new URL("@/assets/images/clients-and-partners/reindo.png", import.meta.url)
    .href,
];

export const clientLogosDark = [
  new URL("@/assets/images/clients-and-partners/boa-dark.png", import.meta.url)
    .href,
  new URL("@/assets/images/clients-and-partners/grm-dark.png", import.meta.url)
    .href,
  new URL(
    "@/assets/images/clients-and-partners/chubb-dark.png",
    import.meta.url
  ).href,
  new URL("@/assets/images/clients-and-partners/fpg-dark.png", import.meta.url)
    .href,
  new URL(
    "@/assets/images/clients-and-partners/heksa-dark.png",
    import.meta.url
  ).href,
  new URL(
    "@/assets/images/clients-and-partners/equity-dark.png",
    import.meta.url
  ).href,
  new URL(
    "@/assets/images/clients-and-partners/indore-dark.png",
    import.meta.url
  ).href,
  new URL(
    "@/assets/images/clients-and-partners/reindo-dark.png",
    import.meta.url
  ).href,
];
