# Panduan frontend Vue — SDK 0.1.0-dev.5

Tanggal: **17 September 2026**. SDK dan dokumentasi mendukung **profil minimal 7 field** serta perbaikan cadence browser (`.4`) dan gerbang gerak (`.5`) tanpa perubahan formula lima hasil.

Siapkan **usia, jenis kelamin, tinggi badan, berat badan, status merokok, konsumsi alkohol, dan penggunaan sepeda motor**. Ketujuh field berlaku sama untuk Male/Female. Tidak perlu meminta pekerjaan, status perkawinan, hobi berbahaya, durasi tidur, paparan layar, aktivitas fisik, atau kehamilan untuk cakupan lima hasil.

| Dokumen | Gunakan untuk |
|---|---|
| [MOTION-GATE-0.1.0-dev.5.md](MOTION-GATE-0.1.0-dev.5.md) | Upgrade `.5`, perbaikan penolakan gerak pada wajah diam, telemetri `state.motion`, pesan UI penolakan, data lapangan dan checklist UAT |
| [CADENCE-AND-PERFORMANCE-0.1.0-dev.4.md](CADENCE-AND-PERFORMANCE-0.1.0-dev.4.md) | Header hosting, telemetry cadence, error dan checklist UAT |
| [FIX-ACCESSORY-DETECTION-0.1.0-dev.3.md](FIX-ACCESSORY-DETECTION-0.1.0-dev.3.md) | Perbaikan false positive kacamata/masker, bukti pengujian dan upgrade aset |
| [FORM-UI-UX.md](FORM-UI-UX.md) | Acuan UI/UX: tujuh input, semua pilihan dan mapping, kontrol, placeholder, pesan kesalahan, dan binding Vue |
| [USER-PROFILE.md](USER-PROFILE.md) | Label form, tipe, validasi, contoh JSON yang diterima SDK, dan field yang dihapus |
| [INTEGRATION.md](INTEGRATION.md) | Instalasi/upgrade, lifecycle kamera, lima hasil, heatmap, dan hosting |
| [API.md](API.md) | Komponen, tipe profil minimal, validator, event, hasil, dan error |
| [VALIDATION.md](VALIDATION.md) | Bukti pengujian dan batas validasi perangkat fisik |

Paket library yang dipakai adalah **`seleris-rppg-vue-0.1.0-dev.5.tgz`**. Pasang paket baru dan salin runtime ke direktori versi `0.1.0-dev.5`; contoh di `examples/vue-vite/` sudah memakai tujuh field. Jangan mencampur library dan runtime dari versi berbeda.

Output tetap **Heart Rate, Breath Rate, HRV SDNN, sistolik, dan diastolik**. Pertahankan penanda `source`/`availability`, termasuk `formula_estimate` untuk tekanan darah. Pemrosesan, quality gate, dan heatmap dilakukan lokal oleh SDK. Build ini tetap prerelease untuk integrasi/UAT; parity pada perangkat fisik belum disertifikasi.
