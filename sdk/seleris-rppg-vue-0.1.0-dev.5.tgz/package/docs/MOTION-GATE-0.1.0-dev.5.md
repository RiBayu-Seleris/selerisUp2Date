# Perbaikan gerbang gerak — 0.1.0-dev.5

Tanggal: **17 September 2026**. Menjawab laporan tim Landing Page v2 *"wajah diam ditolak `MEASUREMENT_MOTION_REJECTED` — 0.1.0-dev.4"*.

Perbaikan cadence di `.4` membuka fase measurement yang sebelumnya tidak tercapai. Di sana detektor gerak web menolak wajah yang diam. Rilis `.5` memperbaiki detektor tersebut. Host kini juga menerima telemetri gerak lengkap, sehingga penyebab penolakan di lapangan bisa ditentukan.

## Ringkasan untuk tim Vue

1. **Upgrade ke `.5`: library dan runtime harus diganti bersama.** Perbaikan berada di runtime iframe; mengganti paket npm saja tidak cukup. Lihat [Langkah upgrade](#langkah-upgrade).
2. **Tidak ada perubahan breaking.** Profil tujuh field, event, lima hasil, dan kode error tetap sama. Event `state` mendapat field tambahan `motion`.
3. **Rekam `state.motion` dan `error.details`** pada setiap sesi UAT. Kirim data tersebut bila masih ada penolakan gerak; formatnya ada di [bagian Data lapangan](#data-lapangan-yang-kami-butuhkan).
4. **Ambang penolakan tidak dilonggarkan.** Batas 35% sampel bergerak, jeda gerak 2 detik, minimum 90 sampel, target 900 sampel, dan ambang pemicu (8%, 17%, 12°/10°/10°, bibir 2 detik) tetap sama. Yang diperbaiki adalah cara detektor membedakan derau dari gerakan.

## Tanggapan atas permintaan laporan

| # | Permintaan | Status di `.5` |
|---|---|---|
| 1 | Teruskan telemetri gerak | **Selesai.** `state.motion` (camelCase) di setiap event `state`; `error.details` pada `MEASUREMENT_MOTION_REJECTED` memuat alasan, delta, jitter kotak, skor dan fraksi bibir, serta hitungan pemicu per alasan. |
| 2 | Longgarkan/samakan syarat pemulihan | **Selesai, dengan pendekatan berbeda.** Pemulihan dinilai pada rata-rata kotak 200 ms; perubahan material ≥3% ukuran kotak atau ≥3° pose dalam 200 ms (sebelumnya satu sampel ≥0,8%/0,8° dalam 500 ms). |
| 3 | Rata-ratakan sel grid mulut | **Selesai.** Setiap sel adalah rata-rata piksel di dalam sel (disampling dengan langkah tetap, bukan satu piksel). Selain itu **ROI mulut dikunci ke kotak anchor**. Simulasi menunjukkan pergeseran ROI akibat getaran kotak adalah sumber derau terbesar, lebih besar daripada derau sensor. |
| 4 | Jendela bibir proporsional terhadap cadence | **Selesai.** Bibir dinyatakan aktif hanya jika ≥30% frame dalam 2 detik terakhir melewati ambang, sehingga perilakunya sama di 15, 24, dan 30 Hz. |
| 5 | Ambang relatif terhadap derau dasar | **Belum.** Setelah poin 3, derau dasar skor bibir turun dari ~0,016 menjadi ~0,003 (ambang 0,018). Ambang adaptif ditunda sampai ada data lapangan dari telemetri poin 1. |
| §8 | Spesifikasi perangkat minimum | **Belum tervalidasi pada perangkat fisik.** Kriteria operasional sementara ada di [Perangkat minimum](#perangkat-minimum). |

## Akar masalah

Logika pemulihan web identik dengan Mobile Kotlin 1.9.2 (`FaceMotionDetector`). Yang berbeda adalah kualitas input.

| Input | Mobile 1.9.2 | Web `.4` |
|---|---|---|
| Kotak wajah | Detektor landmark native | BlazeFace short-range, input 128×128. Satu piksel model ≈ 5 piksel kamera ≈ **2% lebar wajah** |
| Pose | Landmark wajah | 6 keypoint BlazeFace dengan kuantisasi yang sama; yaw/roll dapat berderau beberapa derajat |
| Aktivitas bibir | Bukaan bibir dari landmark, dengan syarat arah berubah ≥2 kali dan rentang ≥0,006 | Luma **satu piksel** per sel dari ROI yang **ikut bergeser** dengan kotak tiap frame |

Ambang pemulihan 0,8% dan 0,8° dirancang untuk derau landmark Mobile. Di web, nilai itu berada di dalam derau detektor, sehingga status `moving` tidak pernah lepas. Ini sesuai temuan laporan.

## Perubahan detektor (`multi_timescale_pose_lip_web_v3`)

| Bagian | `.4` (`multi_timescale_pose_lip_v2`) | `.5` |
|---|---|---|
| Kotak dan pose untuk keputusan | Per frame mentah | Rata-rata jendela waktu 200 ms |
| Pemicu mendadak (8%) | Frame sebelumnya vs frame ini | Rata-rata 200–400 ms lalu vs rata-rata 0–200 ms terakhir |
| Pemicu bertahap (17%) dan pose (12°/10°/10°) | vs anchor | vs anchor, memakai rata-rata 200 ms |
| Perubahan material (menahan `moving`) | Satu sampel dalam 500 ms beda ≥0,8% atau ≥0,8° | Rata-rata 200 ms berubah ≥3% atau ≥3° |
| Lepas dari `moving` | 500 ms tanpa perubahan material | Sama, 500 ms |
| Skor mulut | 72 piksel tunggal, ROI dari kotak frame ini | 72 rata-rata sel, ROI dari kotak anchor (tetap) |
| Deteksi bibir | Durasi >2 s dan ≥5 lonjakan, rantai putus bila jeda >600 ms | Sama, **ditambah** ≥30% frame aktif dalam 2 s terakhir |

Detektor web kini sengaja berbeda dari Mobile (`algorithmVersion` berubah). Status `parityCertified:false` tetap berlaku.

## Hasil simulasi

Simulasi deterministik tanpa kamera memakai model getaran dan seed yang sama dengan laporan tim Vue (bagian 6), ditambah skor mulut dari piksel wajah sintetis. Skrip `scripts/simulate-motion-gate.mjs` ada di repo SDK dan memerlukan runtime yang tidak diminify; tim SDK dapat menjalankannya untuk skenario tambahan atas permintaan. Wajah pada bagian "diam" tidak digerakkan sama sekali. Sel berisi persentase frame berstatus `moving`, lalu hasil gerbang (`REJ` = `MEASUREMENT_MOTION_REJECTED`). Tabel lengkap: `reports/motion-gate-simulation.md`.

### Wajah diam — harus lolos

| Kondisi | `.4` 24 Hz | `.5` 24 Hz | `.4` 30 Hz | `.5` 30 Hz |
|---|---|---|---|---|
| Getaran kotak 1,5% | 26% REJ | **0% ok** | 31% REJ | **0% ok** |
| Getaran kotak 1,8% | 89% REJ | **0% ok** | 91% REJ | **0% ok** |
| Getaran kotak 2,5% | 98% REJ | **0% ok** | 98% REJ | **0% ok** |
| Getaran pose 4° | 80% REJ | **0% ok** | 84% REJ | **0% ok** |
| Piksel: derau sensor σ6 + kotak 1,8% | 57% REJ | **0% ok** | 58% REJ | **0% ok** |
| Napas: goyang ±1% + derau sensor | 46% REJ | **0% ok** | 35% REJ | **0% ok** |
| Drift pelan 10% dalam 30 s | 46% REJ | **0% ok** | 35% REJ | **0% ok** |
| Bicara 2 s lalu diam | 46% REJ | **4% ok** | 35% REJ | **4% ok** |
| Geser sekali 12% lalu diam | 29% REJ | **4% ok** | 31% REJ | **3% ok** |
| Menoleh sekali 20° lalu diam | 29% REJ | **4% ok** | 31% REJ | **4% ok** |

### Gerakan nyata — harus tetap ditolak

| Kondisi | `.4` 24 Hz | `.5` 24 Hz | `.4` 30 Hz | `.5` 30 Hz |
|---|---|---|---|---|
| Bicara terus (mulut 4 Hz) | 46% REJ | 43% REJ | 35% REJ | 35% REJ |
| Bicara 4 s lalu diam | 46% REJ | 23% REJ (jeda >2 s) | 35% REJ | 22% REJ |
| Geleng yaw ±20° | 91% REJ | 86% REJ | 90% REJ | 87% REJ |
| Maju-mundur skala 12% | 0% ok | 8% REJ | 0% ok | 21% REJ |
| Goyang kepala 10% @0,5 Hz | 0% ok | 0% ok | 0% ok | 11% REJ |

Batas yang masih ada:

- Getaran kotak ≥2,5% pada 15 Hz dan ≥3% pada 24 Hz masih bisa ditolak. Cadence 15 Hz sudah ditolak lebih dulu oleh gerbang preflight 24 Hz.
- Goyangan kepala halus yang berkelanjutan kini lebih mungkin terdeteksi daripada di `.4`. Ini disengaja karena gerakan seperti itu merusak sinyal rPPG.
- Skor mulut pada simulasi dihitung dari wajah sintetis, bukan wajah manusia. Validasi akhir tetap memerlukan kamera fisik; lihat [Data lapangan](#data-lapangan-yang-kami-butuhkan).

## Langkah upgrade

```sh
npm install /path/ke/seleris-rppg-vue-0.1.0-dev.5.tgz
npx seleris-copy-assets public/vendor/seleris-rppg/0.1.0-dev.5
```

```ts
const scanner = createScanner(element, {
  assetBaseUrl: '/vendor/seleris-rppg/0.1.0-dev.5/',
  profile,
  language: 'id',
});
```

- Jangan menimpa folder `.4`. Salin ke direktori baru, lalu deploy bundle host dan aset `.5` bersamaan.
- Pastikan `ready.sdkVersion === '0.1.0-dev.5'` dan `version.json` di direktori aset menunjukkan versi yang sama. Cache CDN atau service worker yang masih menyajikan runtime `.4` akan mengembalikan perilaku lama.
- Header COOP/COEP, CSP, dan telemetri cadence dari [CADENCE-AND-PERFORMANCE-0.1.0-dev.4.md](CADENCE-AND-PERFORMANCE-0.1.0-dev.4.md) tetap berlaku.

## Telemetri gerak

### `state.motion`

Dikirim bersama setiap event `state` (maksimum 10 kali/detik saat measurement). Tipe: `MotionTelemetry` dari `@seleris/rppg-vue`.

| Field | Arti |
|---|---|
| `algorithmVersion` | `multi_timescale_pose_lip_web_v3` untuk `.5` |
| `detectorState` | `warming_up`, `tracking`, `moving`. Detektor hanya aktif pada fase measurement dan di-reset saat wajah hilang |
| `active`, `reason` | Status `moving` dan alasannya: `sudden_translation`, `gradual_translation`, `scale_change`, `pose_change`, `persistent_lip_activity` |
| `centerDeltaRatio`, `scaleDeltaRatio` | Delta terbesar (mendadak atau vs anchor), relatif terhadap lebar kotak |
| `poseDeltaDegrees` | Delta pose terbesar vs anchor |
| `boxJitterRatio` | Median perubahan pusat kotak mentah antar-frame selama 1 detik terakhir; indikator derau detektor. Nilainya ≈1,9× getaran per koordinat: getaran 1% ≈ 0,019, 1,8% ≈ 0,035, 2,5% ≈ 0,049 |
| `lipVisualScore`, `lipActiveFraction` | Skor mulut frame terakhir (ambang 0,018) dan fraksi frame aktif dalam 2 detik |
| `lipActivityDetected`, `lipActivityDurationSeconds` | Status bibir persisten dan lama rantai aktivitasnya |
| `triggerCounts` | Jumlah episode `moving` per alasan dalam measurement ini |
| `motionRejectedSamples`, `motionRejectionRatio`, `activeGapSeconds` | Posisi terhadap gerbang (35% atau jeda 2 detik) |

### `error.details` pada `MEASUREMENT_MOTION_REJECTED`

Tipe: `MotionRejectionDetails`. Nama field memakai snake_case (sama dengan `.4`), dengan tambahan `motion_algorithm_version`, `motion_reason`, `motion_trigger_counts`, `motion_center_delta_ratio`, `motion_scale_delta_ratio`, `motion_pose_delta_degrees`, `motion_box_jitter_ratio`, `lip_activity_detected`, `lip_activity_duration_seconds`, `lip_visual_score`, dan `lip_active_fraction`.

### Contoh handler

```ts
import type {MotionRejectionDetails, MotionTelemetry} from '@seleris/rppg-vue';

let lastMotion: MotionTelemetry | null = null;
scanner.on('state', state => {
  if (state.motion?.detectorState !== 'warming_up') lastMotion = state.motion;
});

scanner.on('error', error => {
  if (error.code !== 'MEASUREMENT_MOTION_REJECTED') return;
  const details = error.details as MotionRejectionDetails;
  showRetry(motionHint(details.motion_reason, details.motion_trigger_counts));
  reportDiagnostics({code: error.code, details, lastMotion}); // log internal/UAT, bukan untuk pengguna
});

function motionHint(reason: string | null, counts: Record<string, number>) {
  const dominant = reason ?? Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0];
  switch (dominant) {
    case 'persistent_lip_activity': return 'Jangan berbicara selama pemindaian.';
    case 'pose_change': return 'Tetap menghadap kamera tanpa menoleh.';
    case 'scale_change': return 'Jaga jarak wajah ke kamera tetap sama.';
    default: return 'Tahan kepala tetap diam; sandarkan punggung bila perlu.';
  }
}
```

Guidance `face_moving` selama scan tetap berasal dari SDK (`state.guidance`). Handler di atas hanya untuk pesan setelah penolakan. Jangan membuat hasil pengganti setelah penolakan.

### Membaca telemetri untuk diagnosis

| Pola | Kemungkinan penyebab | Tindakan |
|---|---|---|
| `boxJitterRatio` > 0,045 saat wajah diam | Detektor tidak stabil: cahaya redup, wajah terlalu kecil, blur | Perbaiki cahaya/jarak; kirim data ke tim SDK |
| `triggerCounts.persistent_lip_activity` dominan, pengguna tidak bicara | Skor mulut berderau di kamera tersebut | Kirim `lipVisualScore` dan `lipActiveFraction` ke tim SDK |
| `pose_change` dominan, pengguna tidak menoleh | Keypoint BlazeFace berderau | Kirim `poseDeltaDegrees` ke tim SDK |
| `triggerCounts` tinggi untuk translation/scale | Gerakan nyata (bersandar, bicara dengan kepala) | Pesan UI dan arahan posisi duduk |

## Data lapangan yang kami butuhkan

Bila penolakan gerak masih terjadi, lampirkan data dari laporan `.4` ditambah:

```text
ready.sdkVersion              : 0.1.0-dev.5
state.motion (5 terakhir)     : detectorState, reason, centerDeltaRatio, scaleDeltaRatio,
                                poseDeltaDegrees, boxJitterRatio, lipVisualScore, lipActiveFraction
error.details                 : objek lengkap MEASUREMENT_MOTION_REJECTED
Kondisi                       : diam / bicara / menoleh (catatan penguji), jarak wajah, cahaya
```

Ini cukup untuk menentukan jalur mana yang aktif dan untuk menyetel ambang adaptif (poin 5).

## Perangkat minimum

Belum ada perangkat fisik yang tervalidasi. Pengujian SDK masih memakai Chromium headless di Mac dengan kamera sintetis, ditambah data lapangan dari laporan tim Vue. Sampai matriks perangkat selesai, gunakan **kriteria operasional** berikut sebagai syarat lulus UAT per kombinasi perangkat–browser–kamera. Kriteria ini tidak menyebut kelas hardware:

| Kriteria | Batas | Sumber |
|---|---|---|
| `quality.analyzerRateHz` | ≥24 Hz stabil | gerbang preflight SDK |
| `quality.acceptedRateHz` | ≥18 Hz | gerbang preflight SDK |
| `quality.processing.frameMs.p95` | ≤41,7 ms | anggaran 24 Hz |
| `state.motion.boxJitterRatio` wajah diam | ≤0,045 (median selama measurement) | setara getaran ≈2,3%, di bawah batas aman simulasi `.5` di 24 Hz (2,5%) |
| Scan wajah diam | 5 dari 5 lolos tanpa `MEASUREMENT_MOTION_REJECTED` | UAT |

Perangkat pada laporan (MacBook, FaceTime HD 640×480, Chrome 153, COOP/COEP aktif) memenuhi tiga kriteria cadence dengan `frameMs` p95 9,1 ms. Dua kriteria gerak menunggu uji ulang dengan `.5`.

## Checklist UAT `.5`

1. `ready.sdkVersion === '0.1.0-dev.5'` dan `state.motion.algorithmVersion === 'multi_timescale_pose_lip_web_v3'`.
2. Wajah diam 5×, di dua ruangan dengan cahaya berbeda: semua scan selesai.
3. Bicara terus selama scan: harus `MEASUREMENT_MOTION_REJECTED` dengan alasan `persistent_lip_activity`.
4. Menoleh kiri-kanan berulang: harus ditolak (`pose_change`). Sekali menoleh lalu diam: harus pulih dan scan selesai.
5. Rekam `boxJitterRatio`, `lipVisualScore`, dan `triggerCounts` untuk setiap scan di atas.
6. Checklist cadence `.4` (COOP/COEP, `analyzerRateHz`, `processing`) tetap dijalankan.

## Yang tidak berubah

- Formula dan lima hasil, model ME-rPPG, kernel native/WASM, SQI preflight/final, serta gerbang cahaya, aksesori, dan cadence.
- Ambang pemicu gerak dan kebijakan penolakan (35%, 2 detik, 90 sampel), serta target 900 sampel dalam maksimum 45 detik.
- Kontrak profil, nama event, dan kode error.
