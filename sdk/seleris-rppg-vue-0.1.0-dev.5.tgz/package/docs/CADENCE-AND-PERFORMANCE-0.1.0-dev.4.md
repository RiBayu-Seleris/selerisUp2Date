# Perbaikan cadence browser — 0.1.0-dev.4

> **Versi terbaru: `0.1.0-dev.5`.** Seluruh isi dokumen ini tetap berlaku; ganti `.4` pada perintah instalasi dan `assetBaseUrl` dengan `.5`. Perbaikan gerak ada di [MOTION-GATE-0.1.0-dev.5.md](MOTION-GATE-0.1.0-dev.5.md).

Dokumen ini ditujukan untuk tim integrasi Vue yang sebelumnya menerima `PREFLIGHT_CADENCE_REJECTED`, khususnya ketika `analyzerRateHz` jauh di bawah 24 Hz. Rilis ini memperbaiki jalur pemrosesan browser tanpa menurunkan ambang kualitas atau mengubah formula lima hasil.

## Ringkasan perubahan

| Area | Sebelum | 0.1.0-dev.4 |
|---|---|---|
| Pemeriksaan cahaya | Membaca seluruh frame 640×480 setiap frame | Downsample ke canvas 80×60 sebelum readback |
| ROI wajah | Crop wajah, mulut dan dahi dibaca terpisah | Satu buffer wajah dipakai ulang untuk model, mulut dan dahi |
| Mulut saat preflight | Pixel mulut dibaca walaupun hasil tidak digunakan | Hanya dibaca pada fase measurement |
| Model aksesori | Inferensi sinkron pada main thread setiap 200 ms | Dedicated Web Worker, maksimum 2 kali/detik |
| Antrean ME-rPPG | Maksimum satu frame | Maksimum dua frame, tetap diproses berurutan oleh worker recurrent |
| Kamera | Meminta minimum 15 fps lalu gate menuntut 24 Hz | Meminta minimum 24 fps; kegagalan menjadi `CAMERA_CADENCE_UNSUPPORTED` |
| Telemetri | `cameraFps` sebenarnya throughput analyzer | `cameraRateHz`, `analyzerRateHz`, dan `acceptedRateHz` dipisahkan |
| Jendela analyzer | 120 sampel, dapat menjadi sekitar 11 detik pada perangkat lambat | Jendela waktu empat detik, maksimum 120 sampel |
| Estimasi waktu | Dibagi laju analyzer | Dibagi laju sampel yang benar-benar diterima |

Yang tidak berubah: target 900 sampel, nominal 30 Hz, minimum analyzer 24 Hz, minimum accepted preflight 18 Hz, SQI preflight/final, model ME-rPPG, kernel native/WASM, formula HR/HRV/RR/tekanan darah, serta gate wajah, cahaya, aksesori dan gerak.

## Upgrade wajib library dan runtime

Jangan mencampur bundle `.4` dengan aset `.3`. Worker aksesori baru berada di direktori runtime dan tidak tersedia bila hanya paket JavaScript yang diganti.

```sh
npm install /path/ke/seleris-rppg-vue-0.1.0-dev.4.tgz
npx seleris-copy-assets public/vendor/seleris-rppg/0.1.0-dev.4
```

```ts
const scanner = createScanner(element, {
  assetBaseUrl: '/vendor/seleris-rppg/0.1.0-dev.4/',
  profile,
  language: 'id',
});
```

Pastikan cache CDN/service worker tidak mengarahkan `assetBaseUrl` `.4` ke file `.3`. File `version.json`, event `ready.sdkVersion`, paket npm, dan direktori runtime harus sama-sama menunjukkan `0.1.0-dev.4`.

## Header hosting

Gunakan HTTPS atau localhost. Header berikut sangat disarankan pada halaman induk **dan dokumen iframe** `vendor/seleris-rppg/0.1.0-dev.4/index.html`:

```text
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Embedder-Policy: credentialless
Permissions-Policy: camera=(self), microphone=()
```

`require-corp` dapat menggantikan `credentialless`, tetapi seluruh subresource lintas origin milik host harus memiliki CORS/CORP yang sesuai. Terapkan header pada route scanner terlebih dahulu; COOP/COEP dapat memengaruhi analytics, iframe, gambar, atau resource pihak ketiga pada halaman lain.

Aset scanner tetap harus same-origin. Sajikan `.wasm` sebagai `application/wasm`, `.js`/`.mjs` sebagai JavaScript, dan jangan mengubah 404 aset menjadi halaman SPA.

## Pemeriksaan saat `ready`

```ts
scanner.on('ready', capabilities => {
  if (!capabilities.crossOriginIsolated) {
    console.warn('Scanner berjalan tanpa isolasi lintas-origin; performa WASM dapat menurun.');
  }
  console.info({
    minimumAnalyzerRateHz: capabilities.minimumAnalyzerRateHz, // 24
    minimumAcceptedRateHz: capabilities.minimumAcceptedRateHz, // 18
    cameraRequest: capabilities.requestedCameraRateHz,          // min 24, ideal 30
    accessoryInference: capabilities.accessoryInference,        // dedicated_worker
  });
});
```

`ready` menyatakan model dan aset siap. FPS kamera aktual baru tersedia setelah izin kamera diberikan dan event `quality` mulai diterima.

## Telemetri cadence

```ts
scanner.on('quality', quality => {
  const camera = quality.cameraRateHz;   // getSettings().frameRate, dapat null
  const analyzer = quality.analyzerRateHz; // frame yang selesai masuk analyzer
  const accepted = quality.acceptedRateHz; // hasil yang diterima worker
  const frameP95 = quality.processing?.frameMs?.p95;

  if (analyzer !== null && analyzer < 24) {
    showHint('Perangkat belum mampu memproses kamera dengan cukup cepat.');
  }
  if (frameP95 !== undefined && frameP95 > 41.7) {
    console.warn('Frame processing p95 melebihi anggaran 24 Hz', quality.processing);
  }
});
```

Arti field:

- `cameraRateHz`: konfigurasi track kamera menurut browser; bukan jaminan semua frame diproses.
- `analyzerRateHz`: throughput pipeline main thread dengan jendela empat detik.
- `acceptedRateHz`: cadence sampel yang selesai melalui worker ME-rPPG.
- `processing`: p50/p95/latest untuk total frame, face detection, lighting, accessory dispatch, pembacaan wajah, dan round-trip worker.

`cameraFps` tetap dipertahankan di runtime internal sebagai alias kompatibilitas `analyzerRateHz`, tetapi tidak perlu dipakai oleh integrasi Vue baru.

## Error yang harus ditampilkan

| Kode | Arti dan tindakan host |
|---|---|
| `CAMERA_CADENCE_UNSUPPORTED` | Kamera/browser tidak menerima minimum 24 fps. Sarankan cahaya lebih terang, pilih kamera lain, atau perangkat lain. `details.minimumRateHz` berisi batasnya. |
| `PREFLIGHT_CADENCE_REJECTED` | Throughput analyzer belum 24 Hz dalam waktu preflight. Gunakan data `processing` untuk diagnosis dan retry setelah menutup beban halaman lain. |
| `PREFLIGHT_ACCEPTED_RATE_LOW` | Worker menerima sampel di bawah 18 Hz. Jangan membuat hasil pengganti. |
| `MEASUREMENT_DURATION_EXCEEDED` | 900 sampel tidak terkumpul dalam 45 detik. Retry hanya setelah kondisi/perangkat diperbaiki. |
| `ACCESSORY_WORKER_FAILED` / `ACCESSORY_INFERENCE_FAILED` | Worker/model aksesori gagal dimuat atau dijalankan. Periksa bahwa seluruh aset `.4` terdeploy dan CSP mengizinkan worker same-origin. |
| `MODEL_WORKER_FAILED` / `MODEL_INFERENCE_FAILED` | Worker ME-rPPG gagal. Jangan melewati gate atau menghasilkan nilai formula pengganti. |

Tidak ada profil produksi yang menonaktifkan deteksi aksesori. Heatmap boleh dimatikan, tetapi aksesori tetap diperiksa karena merupakan bagian admission policy. Optimasi `.4` memindahkan beban tersebut dari main thread tanpa menghapus validasinya.

## Checklist UAT

1. Pastikan `ready.sdkVersion === '0.1.0-dev.4'` dan `accessoryInference === 'dedicated_worker'`.
2. Pastikan `crossOriginIsolated === true` pada deployment yang memakai COOP/COEP.
3. Rekam `cameraRateHz`, `analyzerRateHz`, `acceptedRateHz`, `processing.frameMs.p95`, SQI, durasi dan kode penolakan.
4. Uji cahaya depan, gelap, backlight, kacamata, masker, gerak, cancel, retry dan route unmount.
5. Uji minimal Chrome/Edge desktop, Chrome Android, Safari macOS/iOS, serta perangkat kelas minimum produk.
6. Bandingkan hasil rekaman wajah yang sama dengan Mobile 1.9.2 sebelum menyatakan parity perangkat atau akurasi klinis.

Rilis ini menghilangkan bottleneck yang teridentifikasi dan memberi error/telemetri eksplisit apabila perangkat masih tidak memenuhi cadence. Rilis tidak menjamin setiap perangkat lolos: perangkat yang tidak mampu menyediakan atau memproses cadence minimum akan ditolak secara fail-closed.
