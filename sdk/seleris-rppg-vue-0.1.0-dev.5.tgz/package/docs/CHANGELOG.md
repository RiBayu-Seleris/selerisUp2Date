# Perubahan SDK Vue

## 0.1.0-dev.5 — 17 September 2026

- Perbaiki penolakan `MEASUREMENT_MOTION_REJECTED` pada wajah diam. Detektor gerak web (`multi_timescale_pose_lip_web_v3`) menilai kotak dan pose dengan rata-rata 200 ms, dan status `moving` lepas setelah 500 ms tanpa perubahan ≥3% atau ≥3°. Sebelumnya status itu bisa tersangkut oleh getaran BlazeFace ±0,8%.
- Skor mulut memakai rata-rata per sel dengan ROI terkunci ke kotak anchor. Deteksi bibir juga mensyaratkan ≥30% frame aktif dalam 2 detik, sehingga tidak bergantung pada cadence.
- Ambang pemicu gerak dan kebijakan penolakan (35%, jeda 2 detik, 90 sampel) tidak diubah.
- Event `state` menambah `motion` (`MotionTelemetry`). `error.details` pada `MEASUREMENT_MOTION_REJECTED` menambah alasan, delta, jitter kotak, skor/fraksi bibir, dan `motion_trigger_counts` (`MotionRejectionDetails`).
- Self-check `verifyEmbeddedMotionPolicy` mencakup pemulihan dari getaran detektor. Tes browser gerak dan simulasi `scripts/simulate-motion-gate.mjs` ditambahkan.
- Rumus, model, kernel, SQI, cadence, dan gerbang cahaya/aksesori tidak diubah.
- Tanggapan laporan, hasil simulasi, telemetri, dan checklist UAT: [MOTION-GATE-0.1.0-dev.5.md](MOTION-GATE-0.1.0-dev.5.md).

## 0.1.0-dev.4 — 17 September 2026

- Pemeriksaan lighting memakai canvas 80×60, bukan readback seluruh frame 640×480.
- Satu buffer ROI wajah dipakai ulang untuk input ME-rPPG, motion mulut dan RGB dahi; pembacaan mulut tidak lagi berjalan saat preflight.
- Inferensi aksesori dipindahkan ke dedicated Web Worker dan dijalankan maksimum 2 Hz tanpa menghapus gate kacamata/masker.
- Antrean ME-rPPG dinaikkan secara bounded menjadi dua frame; worker recurrent tetap memproses frame secara serial.
- Kamera meminta minimum 24 fps dan melaporkan `CAMERA_CADENCE_UNSUPPORTED` ketika constraint tidak tersedia.
- Event `quality` memisahkan `cameraRateHz`, `analyzerRateHz`, `acceptedRateHz`, serta menambahkan timing `processing` p50/p95. Jendela analyzer kini berbasis empat detik.
- Event `ready` meneruskan `crossOriginIsolated`, batas cadence, konfigurasi kamera dan mode worker aksesori.
- Rumus, model ME-rPPG, kernel native/WASM, target 900 sampel, SQI dan lima output tidak diubah.
- Detail upgrade dan penanganan error: [CADENCE-AND-PERFORMANCE-0.1.0-dev.4.md](CADENCE-AND-PERFORMANCE-0.1.0-dev.4.md).

## 0.1.0-dev.3 — 14 September 2026

- Perbaiki dekuantisasi output deteksi aksesori: raw `1` kini menjadi `1/256`, bukan 100%. Pemetaan label/model dan ambang Mobile tetap sama.
- Perbaiki guidance untuk status `FaceMaskDetected`.
- Reset status aksesori saat wajah hilang/multiple faces dan abaikan hasil inferensi yang terlambat dari pengamatan sebelumnya.
- Validasi kontrak model/output serta cleanup tensor pada jalur error ditambahkan.
- Profil tujuh field, lima hasil, heatmap, SQI, dan formula tetap sama. Paket runtime dan contoh Vue memakai direktori versi `.3`.
- Akar masalah, bukti regresi, dan langkah upgrade: [FIX-ACCESSORY-DETECTION-0.1.0-dev.3.md](FIX-ACCESSORY-DETECTION-0.1.0-dev.3.md).

## 0.1.0-dev.2 — 9 September 2026

- Profil wajib menjadi tujuh field: `age`, `sex`, `heightCm`, `weightKg`, `lifestyle.smoking`, `lifestyle.alcohol`, `lifestyle.motorcycle`. Male/Female memakai bentuk yang sama; kehamilan dan enam pertanyaan lifestyle lainnya tidak diperlukan.
- Tipe TypeScript, validator, snapshot profil, bridge iframe dan contoh Vue memakai kontrak minimal. Jawaban kosong ditolak; boolean `false` tetap valid. Field tambahan dari objek lama diabaikan dan tidak diteruskan.
- Perhitungan lima hasil menggunakan formula Mobile yang sama, dengan jalur yang berhenti sebelum menghitung metric/risk/score Care lainnya. Tidak ada jawaban lifestyle buatan untuk melengkapi kontrak Care lama.
- Unit lima hasil dipastikan `bpm`, `napas/menit`, `ms`, `mmHg`, `mmHg`; memperbaiki placeholder `unit` yang dapat terbawa dari template Care pada versi sebelumnya. Nilai, pembulatan dan penanda sumber hasil tidak diubah.
- Dokumentasi, contoh frontend, versi direktori aset dan tarball distribusi diperbarui bersama. Lihat [INTEGRATION.md](INTEGRATION.md) untuk upgrade dari `0.1.0-dev.1`.
- Pengujian tambahan membandingkan profil minimal dengan Mobile Kotlin, memvariasikan field yang dihapus, mengamati input nyata melalui bridge, dan memeriksa finalisasi lima hasil di browser dengan analisis sintetis. Rincian di [VALIDATION.md](VALIDATION.md).

Heatmap, algoritma native/WASM, model, pemeriksaan cahaya/kacamata, SQI, motion, spoof screening dan batas waktu scan tetap mengikuti implementasi sebelumnya. Build tetap prerelease untuk integrasi/UAT; kesetaraan perangkat fisik belum disertifikasi.

## 0.1.0-dev.1 — 8 September 2026

Build integrasi awal dengan profil Care lengkap, lima output, pemrosesan lokal, heatmap Mobile 1.9.2 dan paket Vue/WASM. Revisi dokumentasi profil tujuh field pada tanggal yang sama belum mengubah validator versi ini; dukungan runtime tersedia mulai `0.1.0-dev.2`.
